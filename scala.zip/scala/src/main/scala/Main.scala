import Office.Office
import Roles.{Coach, Manager, Student}
import Token.{Stock, Wallet}

import scala.collection.mutable.ListBuffer

object Main extends App{
  var stock  = new Stock()

  var student = new Student(
    1,
    "Nastya",
    new Wallet( stock, 0, 0 ),
    "Java"
  );

  var coach = new Coach(
    1,
    "Mikhail",
    new Wallet( stock, 10, 100 ),
    ListBuffer( "Java", "C++" )
  );

  var manager = new Manager(
    1,
    "Maksym",
    new Wallet( stock, 20, 200 )
  );

  var office = new Office(
    manager,
    ListBuffer( coach )
  );

  println(
    "Before simulate:\n" +
      stock + "\n" +
      student + "\n" +
      coach + "\n" +
      manager + "\n"
  );

  println("SIMULATE")
  coach.selectStudent( ListBuffer( student ) );
  office.addCoach( coach );
  office.study( coach );
  manager.buyTokens( 2 );
  manager.paySalary( coach, 1 );

  println(
    "\nAfter simulate:\n" +
      stock + "\n" +
      student + "\n" +
      coach + "\n" +
      manager + "\n"
  );
}
