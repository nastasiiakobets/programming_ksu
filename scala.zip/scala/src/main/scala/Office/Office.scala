package Office

import Roles.{Coach, Manager, Student}

import scala.collection.mutable.ListBuffer

class Office(  manager : Manager, coaches: ListBuffer[Coach] ) {

  def addCoach( coach: Coach ) : Unit = {
    coaches.addOne( coach );
  }

  def removeCoach( coach: Coach ) : Unit = {
    coaches -= coach;
  }

  def coachSalary( coach: Coach, salary : Double ) : Unit = {
    for( c <- coaches ) {
      if( c.getID == coach.getID ) {
        manager.paySalary( c, salary );
      }
    }
  }

  def study( coach: Coach ) : Unit = {
    var students = coach.getStudents;

    students.foreach( student =>
    {
      student.doTask();
      coach.setMark( student );
    });
  }

  override def toString: String = {
    var coachesString : String = "";

    coaches.foreach( coach => coachesString =  coachesString + coach.toString + "\n" )

    return  "Office members: " + "\n" +
            manager + "\n" +
            coachesString;
  }
}
