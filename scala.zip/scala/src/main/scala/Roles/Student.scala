package Roles

import Token.Wallet

import scala.collection.mutable.ListBuffer

class Student(
               id: Int,
               name: String,
               wallet: Wallet,
               desiredKnowledge: String ) extends Applicants( id, name, wallet ) {

  def doTask() : Unit = {
    println( "Task was done by " +  this.name )
  }

  def getReward( mark: Int ) : Unit = {
    var tokensToGet = mark * 2;
    wallet.addTokens( tokensToGet );

    println( this.name + " got " + tokensToGet.toString + " tokens");
  }

  override def toString: String = {
    "Student " + name + " (" + wallet + ")";
  }

  def getDesiredKnowledge : String = desiredKnowledge;
}
