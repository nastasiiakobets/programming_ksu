package Roles

import Token.Wallet

abstract class Applicants( id : Int, name: String, wallet: Wallet ) {

  def buyTokens( tokensToBuy: Double ) : Unit = {
    wallet.buyTokens( tokensToBuy );
  };
  def sellTokens( tokensToSell: Double ) : Unit = {
    wallet.sellTokens( tokensToSell );
  };

  def getWallet : Wallet = wallet;
  def getName : String = name;
}
