package Roles

import Office.Office
import Token.Wallet

class Manager(
               id: Int,
               name: String,
               wallet: Wallet ) extends Applicants( id, name, wallet ){
  def addCoach( office: Office, coach: Coach ) : Unit = {
    office.addCoach( coach )
  }

  def removeCoach( office: Office, coach: Coach ) : Unit = {
    office.removeCoach( coach );
  }

  def paySalary( coach: Coach, tokensToPay: Double ) : Unit = {
    wallet.transferTokens( tokensToPay, this, coach );

    println( this.name + " payed " + tokensToPay + " tokens to " + coach.getName );
  }

  override def toString: String = {
    "Manager " + name + " (" + wallet + ")";
  }

}
