package Roles

import Token.Wallet

import scala.collection.mutable.ListBuffer
import scala.util.Random

class Coach(
             id: Int,
             name: String,
             wallet: Wallet,
             knowledge: ListBuffer[ String ] ) extends Applicants( id, name, wallet ) {

  private var students : ListBuffer[ Student ] = ListBuffer();

  def selectStudent( freeStudents : ListBuffer[ Student ] ) : Unit = {
    knowledge.foreach( coachKnowledge => {
      freeStudents.foreach( student => {
        if ( coachKnowledge.contains( student.getDesiredKnowledge ) ) {
          students.addOne( student );
        }
      });
    });
  }

  def setMark( student : Student ) : Unit = {
    val rand = new Random();

    val mark = rand.nextInt( 5 );
    println( this.name + " set " + mark.toString + " to " + student.getName );

    student.getReward( mark );
  }

  override def toString : String = {
    var knowledgeString : String = "";

    knowledge.foreach( coachKnowledge => knowledgeString = knowledgeString + coachKnowledge + ", " );

    return "Coach " + name + ". " + "Knowledge: " + knowledgeString + ". (" + wallet + ")";
  }

  def getStudents : ListBuffer[ Student ] = students;
  def getID : Int = id;
}
