package Token

import Roles.Applicants

class Wallet ( stock : Stock, tokens : Double, dollars : Double ) {
  var Tokens : Double = tokens;
  var Dollars : Double = dollars

  def buyTokens( amountToBuy : Double ) : Unit = {
    var price: Double = stock.getSellPrice * amountToBuy;

    if(Dollars >= price) {
      Dollars -= price;
      Tokens += amountToBuy;
      stock.sellTokens( amountToBuy );
    }
    else {
      println("Not enough dollars!")
    }
  }

  def sellTokens( amountToSell : Double ) : Unit = {
    var price: Double = stock.getSellPrice * amountToSell;

    if( Tokens >= amountToSell ) {
      Tokens -= amountToSell;
      Dollars += price;
      stock.buyTokens( amountToSell );
    }
    else {
      println("Not enough tokens!");
    }
  }

  def addTokens( tokensToAdd: Double ): Unit = {
    Tokens += tokensToAdd;
    stock.removeTokens( tokensToAdd );
  }

  def transferTokens( tokensToTransfer: Double, applicantToSend: Applicants, applicantToReceive: Applicants ): Unit = {
    applicantToSend.getWallet.setTokens( applicantToSend.getWallet.getTokens - tokensToTransfer );

    applicantToReceive.getWallet.setTokens( applicantToReceive.getWallet.getTokens + tokensToTransfer );
  }

  override def toString : String = {
    Tokens + " tokens; " + Dollars + " dollars";
  }

  def getTokens: Double = Tokens;
  def getDollars: Double = Dollars;
  def setTokens( tokens: Double ) : Unit = Tokens = tokens;
}

