package Token

class Stock() {
  private var amountOfTokens : Double = 100;
  private var buyPrice : Double = 5;
  private var sellPrice : Double = buyPrice * 0.95;

  def sellTokens( amountToSell : Double ) : Unit = {
    println( amountToSell + " tokens were sold on stock." );

    if( amountToSell > amountOfTokens ) {
      generateTokens(amountToSell + amountOfTokens + 10);
    }

    amountOfTokens -= amountToSell;
    changePrices( amountToSell * 0.01 );
  }

  def buyTokens( amountToBuy : Double ) : Unit = {
    println( amountToBuy + " tokens were bought on stock." );

    amountOfTokens += amountToBuy;
    changePrices( amountToBuy * -0.01 );
  }

  def removeTokens( amountToRemove : Double ) : Unit = {
    amountOfTokens -= amountToRemove;
    changePrices(amountToRemove * 0.01);
  };

  override def toString: String = {
    return  "Amount of tokens on StockMarket: " + amountOfTokens.toString + "\n" +
            "BuyPrice: " + buyPrice.toString + "\n" +
            "SellPrice: " + sellPrice.toString + "\n"
  }

  def getBuyPrice: Double = buyPrice

  def getSellPrice: Double = sellPrice

  private def generateTokens(amountToGenerate: Double): Unit = {
    amountOfTokens += amountToGenerate;

    this.buyPrice = buyPrice * ( 1 - amountToGenerate / amountOfTokens );
    this.sellPrice = buyPrice * 0.95;
  }

  private def changePrices( changePrice: Double ): Unit = {
    buyPrice += changePrice;

    if (buyPrice <= 0) {
      buyPrice = 5;
      sellPrice = buyPrice * 0.95;
      amountOfTokens = 100;
    }
  }
}
