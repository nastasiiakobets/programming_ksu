﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 25.12.2022
 * Time: 5:00
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace UserControls
{
	partial class UserControl1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label Subject;
		private System.Windows.Forms.Label Surname_teacher_2;
		private System.Windows.Forms.Label Name_teacher_2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.Subject = new System.Windows.Forms.Label();
			this.Surname_teacher_2 = new System.Windows.Forms.Label();
			this.Name_teacher_2 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Gainsboro;
			this.pictureBox2.Location = new System.Drawing.Point(52, 28);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(216, 158);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			// 
			// Subject
			// 
			this.Subject.Location = new System.Drawing.Point(327, 143);
			this.Subject.Name = "Subject";
			this.Subject.Size = new System.Drawing.Size(100, 23);
			this.Subject.TabIndex = 6;
			// 
			// Surname_teacher_2
			// 
			this.Surname_teacher_2.Location = new System.Drawing.Point(327, 87);
			this.Surname_teacher_2.Name = "Surname_teacher_2";
			this.Surname_teacher_2.Size = new System.Drawing.Size(100, 23);
			this.Surname_teacher_2.TabIndex = 5;
			// 
			// Name_teacher_2
			// 
			this.Name_teacher_2.Location = new System.Drawing.Point(327, 40);
			this.Name_teacher_2.Name = "Name_teacher_2";
			this.Name_teacher_2.Size = new System.Drawing.Size(100, 23);
			this.Name_teacher_2.TabIndex = 4;
			// 
			// UserControl1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Info;
			this.Controls.Add(this.Subject);
			this.Controls.Add(this.Surname_teacher_2);
			this.Controls.Add(this.Name_teacher_2);
			this.Controls.Add(this.pictureBox2);
			this.Name = "UserControl1";
			this.Size = new System.Drawing.Size(948, 220);
			this.Load += new System.EventHandler(this.UserControl1Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);

		}
	}
}
