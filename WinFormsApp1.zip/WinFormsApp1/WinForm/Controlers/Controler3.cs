﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1.UserControls
{
	public partial class Controler3 : UserControl
	{
		private MainForm mainform;
		private Coursework coursework;
		private Student student;
		
		
		public Controler3(Coursework coursework, MainForm mainform,Student student)
		{
			this.mainform = mainform;
			this.coursework = coursework;
			this.student = student;
			
			InitializeComponent();
			
			richTextBox1.Text =
				"Назва: " + coursework.Title + '\n' + 
				"Опис: " + coursework.Description;
			
			deadline.Text = coursework.Date.ToShortDateString();
			if(coursework.Date.Date < DateTime.Today)
			{
				deadline.ForeColor = Color.Red;
			}
		}
		void button1_Click(object sender, EventArgs e)
		{
			student.RemoveCoursework(coursework);
			mainform.PrintTeacher();
		}

        private void Controler3_Load(object sender, EventArgs e)
        {

        }
    }
}
