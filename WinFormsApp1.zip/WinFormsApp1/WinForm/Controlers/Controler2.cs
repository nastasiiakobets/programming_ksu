﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using WinFormsApp1;

namespace WinFormsApp1.UserControls
{

    public partial class Controler2 : UserControl
    {
        private MainForm _mainform;
        private Student _student;
        private Teacher _teacher;

        public Student student
        {
            get { return _student; }
            set { this._student = value; }
        }

        public Controler2(Student student, MainForm mainform, Teacher teacher)
        {
            this._mainform = mainform;
            this._student = student;
            this._teacher = teacher;

            InitializeComponent();

            label1.Text = student.Name;
            label2.Text = student.Surname;
            key_name.Text = student.Ssubj.ToString();
            pictureBox1.Image = student.Photo;
        }
        void button1_Click(object sender, EventArgs e)
        {
            _teacher.removeStudent(student);
            _mainform.PrintTeacher();
        }
        void addCursework_Click(object sender, EventArgs e)
        {
            _mainform.OpenItem(new AddCoursework(_mainform, this));
        }

        private void Controler2_Load(object sender, EventArgs e)
        {

        }
    }
}