﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class Adress
    {
        private string country;
        private string city;
        private string street;
        private int house;

        public Adress()
        {
            country = "Ukraine";
            city = "Kherson";
            street = "ul. Ushakova";
            house = 38;
        }

        public Adress(string country1, string city1, string street1, int house1)
        {
            country1 = country;
            city1 = city;
            street1 = street;
            house1 = house;
        }
        public Adress(Adress A)
        {
            this.country = A.country;
            this.city = A.city;
            this.street = A.street;
            this.house = A.house;
        }

        public string adressToString()
        {
            return (
                "Країна: " + this.country + "\n" +
                "Місто: " + this.city + "\n" +
                "Вулиця: " + this.street + "\n" +
                "Будинок: " + this.house.ToString()
                );
        }
        public Adress inputAdress()
        {
            Console.WriteLine("Країна: "); 
            string country = Console.ReadLine();
            Console.WriteLine("Місто: "); 
            string city = Console.ReadLine();
            Console.WriteLine("Вулиця: "); 
            string street = Console.ReadLine();
            Console.WriteLine("Будинок: ");
            int house = int.Parse(Console.ReadLine());

            Adress adress = new Adress(country, city, street, house);
            return adress;
        }


        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string Street
        {
            get { return street; }
            set {street = value; }
        }

        public int House
        {
            get { return house; }
            set { house = value; }
        }
    }
}
