﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1
{
	
	public partial class AddCoursework : Form
	{
		private MainForm _mainform;
		private UserControls.Controler2 _usercontrol2;
		public AddCoursework(MainForm mainform, UserControls.Controler2 usercontrol2)
		{
			this._mainform = mainform;
			this._usercontrol2 = usercontrol2;
			InitializeComponent();
			
		}
		void button1_Click(object sender, EventArgs e)
		{
			string Titles = richTextBox1.Text;
			string Descriptions = richTextBox2.Text;
			DateTime deadline = DateTime.Parse(dateTimePicker1.Text);
			
			_usercontrol2.student.AddCoursework(new Coursework(Titles,Descriptions,deadline));
			_mainform.PrintTeacher();
		}
		void richTextBox1_TextChanged(object sender, EventArgs e)
		{
			
		}

        private void AddCourse_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
