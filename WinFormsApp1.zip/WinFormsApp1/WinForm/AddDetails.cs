﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;

namespace WinForm
{
	
	public partial class AddDetails : Form
	{
		private MainForm _mainform;
		private ListTeacher _listteacher;
		
		public AddDetails(MainForm mainform,ListTeacher listteacher)
		{
			this._mainform = mainform;
			this._listteacher = listteacher;
			InitializeComponent();
			
			new_TreeView();
			new_chart();
		}
		
		private void new_TreeView()
		{
			DateTime dedline;
			Color color = Color.Black;
			treeView1.Nodes.Clear();
			for(int i = 0;i < _mainform.teacher_list.LTeacher.Count;i++)
			{
				treeView1.Nodes.Add(_mainform.teacher_list.LTeacher[i].Name + _mainform.teacher_list.LTeacher[i].Surname);
				for(int k = 0;k < _mainform.teacher_list.LTeacher[i].ListStudent.Count;k++)
				{
					treeView1.Nodes[i].Nodes.Add(_mainform.teacher_list.LTeacher[i].ListStudent[k].Name + _mainform.teacher_list.LTeacher[i].ListStudent[k].Surname);
					for(int j = 0; j < _mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework.Count;j++)
					{
						treeView1.Nodes[i].Nodes[k].Nodes.Add(_mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Title);
						dedline = _mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Date;
						if(dedline<DateTime.Today)
						{
							color = Color.Purple;
						}
						else
						{
							color = Color.Black;
						}
						treeView1.Nodes[i].Nodes[k].Nodes[j].Nodes.Add((_mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Date).ToShortDateString()).ForeColor = color;
					}
					 
				}
			}
		}
		
		private void new_chart()
		{
			chart1.Series[0].Points.Clear();
            chart2.Series[0].Points.Clear();

            for (int i = 0; i < _mainform.teacher_list.LTeacher.Count; i++)
            {
            	Teacher itemChart2 = _mainform.teacher_list.LTeacher[i];
            	chart2.Series["Students"].Points.AddXY(itemChart2.Name + itemChart2.Surname, itemChart2.ListStudent.Count);
                for (int j = 0; j < _mainform.teacher_list.LTeacher[i].ListStudent.Count; j++)
                {
                    Student itemChart = _mainform.teacher_list.LTeacher[i].ListStudent[j];
                    chart1.Series["Coursework"].Points.AddXY(itemChart.Name + itemChart.Surname, itemChart.ListCoursework.Count);
                }
            }
		}
	}
}
