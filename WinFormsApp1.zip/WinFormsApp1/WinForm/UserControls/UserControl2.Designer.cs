﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 25.12.2022
 * Time: 19:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace WinForm.UserControls
{
	partial class UserControl2
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button delete_Student;
		private System.Windows.Forms.Button addCursework;
		private System.Windows.Forms.Label key_name;
		
		/// <summary>
		/// Disposes resources used by the control.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.delete_Student = new System.Windows.Forms.Button();
			this.addCursework = new System.Windows.Forms.Button();
			this.key_name = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Gray;
			this.pictureBox1.Location = new System.Drawing.Point(33, 28);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(198, 139);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(280, 28);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "label1";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(280, 79);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "label2";
			// 
			// delete_Student
			// 
			this.delete_Student.AutoSize = true;
			this.delete_Student.Location = new System.Drawing.Point(513, 28);
			this.delete_Student.Name = "delete_Student";
			this.delete_Student.Size = new System.Drawing.Size(219, 46);
			this.delete_Student.TabIndex = 3;
			this.delete_Student.Text = "Удалить";
			this.delete_Student.UseVisualStyleBackColor = true;
			this.delete_Student.Click += new System.EventHandler(this.button1_Click);
			// 
			// addCursework
			// 
			this.addCursework.AutoSize = true;
			this.addCursework.Location = new System.Drawing.Point(513, 122);
			this.addCursework.Name = "addCursework";
			this.addCursework.Size = new System.Drawing.Size(219, 46);
			this.addCursework.TabIndex = 4;
			this.addCursework.Text = "Показать курсовую";
			this.addCursework.UseVisualStyleBackColor = true;
			this.addCursework.Click += new System.EventHandler(this.addCursework_Click);
			// 
			// key_name
			// 
			this.key_name.AutoSize = true;
			this.key_name.Location = new System.Drawing.Point(280, 133);
			this.key_name.Name = "key_name";
			this.key_name.Size = new System.Drawing.Size(70, 25);
			this.key_name.TabIndex = 6;
			this.key_name.Text = "label3";
			// 
			// UserControl2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Info;
			this.Controls.Add(this.key_name);
			this.Controls.Add(this.addCursework);
			this.Controls.Add(this.delete_Student);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Name = "UserControl2";
			this.Size = new System.Drawing.Size(864, 196);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
