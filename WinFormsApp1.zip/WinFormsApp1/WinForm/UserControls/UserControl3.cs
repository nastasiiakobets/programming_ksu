﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace WinForm.UserControls
{
	public partial class UserControl3 : UserControl
	{
		private MainForm _mainform;
		private Coursework _coursework;
		private Student _student;
		
		
		public UserControl3(Coursework coursework, MainForm mainform,Student student)
		{
			this._mainform = mainform;
			this._coursework = coursework;
			this._student = student;
			
			InitializeComponent();
			
			richTextBox1.Text =
				"Title: " + _coursework.Title + '\n' + 
				"Description: " + _coursework.Description;
			
			deadline.Text = _coursework.Date.ToShortDateString();
			if(_coursework.Date.Date < DateTime.Today)
			{
				deadline.ForeColor = Color.Purple;
			}
		}
		void button1_Click(object sender, EventArgs e)
		{
			_student.removeCoursework(_coursework);
			_mainform.PrintTeacher();
		}
		
	}
}
