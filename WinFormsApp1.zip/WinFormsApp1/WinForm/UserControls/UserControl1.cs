﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace WinForm.UserControls
{
	
	public partial class UserControl1 : UserControl
	{
		private Teacher teacher;
		private MainForm _mainform;
		
		public Teacher Teach
		{
			get{return teacher;}
			set{teacher = value;}
		}
		
		public UserControl1(Teacher teach,MainForm mainform)
		{
			this.teacher = teach;
			this._mainform = mainform;
			InitializeComponent();
			
			teacher_name.Text = teacher.Name;
			teacher_surname.Text = teacher.Surname;
			key_name.Text = teacher.TKey.ToString();
			teacher_image.Image = teacher.Photo;
		}
		void delete_teacher_Click(object sender, EventArgs e)
		{
			_mainform.teacher_list.removeTeacher(Teach);
			_mainform.PrintTeacher();
		}
		void add_student_Click(object sender, EventArgs e)
		{
			_mainform.OpenItem(new AddFormStudent(_mainform,this));
			
		}
		
	}
}
