﻿/*
 * Created by SharpDevelop.
 * User: User
 * Date: 25.12.2022
 * Time: 19:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace WinForm.UserControls
{
	partial class UserControl1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label teacher_name;
		private System.Windows.Forms.Label teacher_surname;
		private System.Windows.Forms.Button delete_teacher;
		private System.Windows.Forms.Button add_student;
		private System.Windows.Forms.PictureBox teacher_image;
		private System.Windows.Forms.Label key_name;
		
		/// <summary>
		/// Disposes resources used by the control.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.teacher_name = new System.Windows.Forms.Label();
			this.teacher_surname = new System.Windows.Forms.Label();
			this.teacher_image = new System.Windows.Forms.PictureBox();
			this.delete_teacher = new System.Windows.Forms.Button();
			this.add_student = new System.Windows.Forms.Button();
			this.key_name = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.teacher_image)).BeginInit();
			this.SuspendLayout();
			// 
			// teacher_name
			// 
			this.teacher_name.AutoSize = true;
			this.teacher_name.Location = new System.Drawing.Point(270, 19);
			this.teacher_name.Name = "teacher_name";
			this.teacher_name.Size = new System.Drawing.Size(70, 25);
			this.teacher_name.TabIndex = 0;
			this.teacher_name.Text = "label1";
			// 
			// teacher_surname
			// 
			this.teacher_surname.AutoSize = true;
			this.teacher_surname.Location = new System.Drawing.Point(270, 79);
			this.teacher_surname.Name = "teacher_surname";
			this.teacher_surname.Size = new System.Drawing.Size(70, 25);
			this.teacher_surname.TabIndex = 1;
			this.teacher_surname.Text = "label2";
			// 
			// teacher_image
			// 
			this.teacher_image.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.teacher_image.Location = new System.Drawing.Point(25, 19);
			this.teacher_image.Name = "teacher_image";
			this.teacher_image.Size = new System.Drawing.Size(198, 155);
			this.teacher_image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.teacher_image.TabIndex = 2;
			this.teacher_image.TabStop = false;
			// 
			// delete_teacher
			// 
			this.delete_teacher.Location = new System.Drawing.Point(464, 19);
			this.delete_teacher.Name = "delete_teacher";
			this.delete_teacher.Size = new System.Drawing.Size(214, 50);
			this.delete_teacher.TabIndex = 3;
			this.delete_teacher.Text = "Удалить";
			this.delete_teacher.UseVisualStyleBackColor = true;
			this.delete_teacher.Click += new System.EventHandler(this.delete_teacher_Click);
			// 
			// add_student
			// 
			this.add_student.AutoSize = true;
			this.add_student.Location = new System.Drawing.Point(464, 117);
			this.add_student.Name = "add_student";
			this.add_student.Size = new System.Drawing.Size(214, 48);
			this.add_student.TabIndex = 4;
			this.add_student.Text = "Показать студента";
			this.add_student.UseVisualStyleBackColor = true;
			this.add_student.Click += new System.EventHandler(this.add_student_Click);
			// 
			// key_name
			// 
			this.key_name.AutoSize = true;
			this.key_name.Location = new System.Drawing.Point(270, 141);
			this.key_name.Name = "key_name";
			this.key_name.Size = new System.Drawing.Size(70, 25);
			this.key_name.TabIndex = 5;
			this.key_name.Text = "label3";
			// 
			// UserControl1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Info;
			this.Controls.Add(this.key_name);
			this.Controls.Add(this.add_student);
			this.Controls.Add(this.delete_teacher);
			this.Controls.Add(this.teacher_image);
			this.Controls.Add(this.teacher_surname);
			this.Controls.Add(this.teacher_name);
			this.Name = "UserControl1";
			this.Size = new System.Drawing.Size(864, 196);
			((System.ComponentModel.ISupportInitialize)(this.teacher_image)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
