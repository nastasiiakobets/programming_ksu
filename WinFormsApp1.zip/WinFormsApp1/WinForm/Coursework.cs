﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class Coursework
    {
        private string title;
        private string description;
        private DateTime date;

        public Coursework()
        {
            title = "Курсова робота 1";
            description = "з теми: Поведінка тварин. Види і особливості";
            date = DateTime.Today;
        }
        public Coursework(string title1, string description1, DateTime date1)
        {
            title = title1;
            description = description1;
            date = date1;
        }
        public Coursework(Coursework C)
        {
            this.title = C.title;
            this.description = C.description;
            this.date = C.date;
        }
        public string ToString()
        {
            return
                ("Назва: " + this.Title + "\n" +
                 "Опис: " + this.Description + "\n" +
                 "Дедлайн: " + this.Date.ToString());
        }
       public void printInfo() => this.ToString();



        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
    }
}
