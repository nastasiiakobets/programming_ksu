﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1
{
	
	public partial class AddTeacher : Form
	{
		private MainForm _mainform;
		
		public AddTeacher(MainForm mainfrom)
		{
			this._mainform = mainfrom;
			InitializeComponent();
			
		}
		void button_add_teacher_Click(object sender, EventArgs e)
		{
			label1.Text = " ";
			string teach_name = textBox_Name.Text;
			string teach_surname = textBox_Surname.Text;
			Image photos = pictureBox1.Image;
			Subjects key;
			if (Subjects.TryParse(textBox_key.Text, out key)) 
			{
				
				_mainform.teacher_list.add(new Teacher(teach_name,teach_surname,photos,key));
				_mainform.PrintTeacher();
				
			}
			else
			{
				label1.Text = "Поле Предмет введено неправильно";
			}
			
		}
		void pictureBox1_Click(object sender, EventArgs e)
		{
			openFileDialog1.ShowDialog();
			string FilePath = openFileDialog1.FileName;
			pictureBox1.Image = Image.FromFile(FilePath);
		}

        private void AddForm_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
