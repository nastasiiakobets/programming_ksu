﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace WinFormsApp1
{
    public class Teacher : Human
    {
        private int salary;
        private int number;
        private Subjects subj;
        private List<Student> listofStudent;
        public Teacher() : base()
        {
            listofStudent = new List<Student>();
        }
        
        public Teacher(string name,string surname,Image photo,Subjects subj1) 
            : base(name,surname,photo)
        {
        	subj1 = subj;
        	listofStudent = new List<Student>();
        }
        
        public Teacher(string name1, string surname1, int age1, Adress adress1, string email1, Image photo1, int salary1, int numb1, Subjects subj1) 
            : base(name1, surname1, age1, adress1, email1, photo1)
        {
            salary1 = salary;
            numb1 = number;
            subj1 = subj;
        }
        public string addStudent(Student stud)
		{
        	if (!(this.subj == stud.Ssubj))
    		{
    			return "Назва предмету неправильна";
    		}
    		
        	if (!(listofStudent.Count <= number))
    		{
    			return "Кількість студентів переповнено";
    		}

    		listofStudent.Add(stud);
    		return "" ;
		}
        
        
        
        public void removeStudent(Student student)
        {
            if (listofStudent.Contains(student))
            {
                listofStudent.Remove(student);
            }
        }
        public void clearStudent()
        {
            listofStudent.Clear();
        }
        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        public int Numofseat
        {
            get { return number; }
            set { number = value; }
        }
        public Subjects TSubj
        {
            get { return subj; }
            set { subj = value; }
        }
        public List<Student> ListStudent
        {
            get { return listofStudent; }
        }
    }
}
