﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1
{
	
	public partial class AddStudent : Form
	{
		private MainForm _mainform;
		private UserControls.Controler1 _userControl1;
		
		
		public AddStudent(MainForm mainform, UserControls.Controler1 usercontrol1)
		{
			this._mainform = mainform;
			this._userControl1 = usercontrol1;
			InitializeComponent();
			
		}
		void button_add_student_Click(object sender, EventArgs e)
		{
			label1.Text = " ";
			string stud_name = textBox_Name.Text;
			string stud_surname = textBox_Surname.Text;
			Image photos = pictureBox1.Image;
			Subjects subj;
			if (Subjects.TryParse(textBox_key.Text, out subj)) 
			{
				
				_userControl1.Teach.addStudent(new Student(stud_name,stud_surname,photos,subj));
				string value = _userControl1.Teach.addStudent(new Student(stud_name,stud_surname,photos,subj));
				if(!(string.IsNullOrWhiteSpace(value)))
				{
					label1.Text = value;
				}
				_mainform.PrintTeacher();
			
			}
			else
			{
				label1.Text = "Поле Предмет введено неправильно";
			}
		}
		void pictureBox1_Click(object sender, EventArgs e)
		{
			openFileDialog1.ShowDialog();
			string FilePath = openFileDialog1.FileName;
			pictureBox1.Image = Image.FromFile(FilePath);
		}

        private void AddFormStudent_Load(object sender, EventArgs e)
        {

        }

        private void textBox_key_TextChanged(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
    }
}
