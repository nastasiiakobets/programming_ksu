﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinForm
{
	
	public partial class AddForm : Form
	{
		private MainForm _mainform;
		
		public AddForm(MainForm mainfrom)
		{
			this._mainform = mainfrom;
			InitializeComponent();
			
		}
		void button_add_teacher_Click(object sender, EventArgs e)
		{
			label1.Text = " ";
			string teach_name = textBox_Name.Text;
			string teach_surname = textBox_Surname.Text;
			Image photos = pictureBox1.Image;
			Key key;
			if (Key.TryParse(textBox_key.Text, out key)) 
			{
				
				_mainform.teacher_list.add(new Teacher(teach_name,teach_surname,photos,key));
				_mainform.PrintTeacher();
				
			}
			else
			{
				label1.Text = "Поле Key введено не корректно";
			}
			
		}
		void pictureBox1_Click(object sender, EventArgs e)
		{
			openFileDialog1.ShowDialog();
			string FilePath = openFileDialog1.FileName;
			pictureBox1.Image = Image.FromFile(FilePath);
		}
		
	}
}
