﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace WinFormsApp1
{
    public class Student : Human
    {
        private int group;
        private Subjects subj;
        private List<Coursework> listofCoursework;


        public Student() : base()
        {
            listofCoursework = new List<Coursework>();
        }
        public Student(string name1, string surname1, int age1, Adress adress1, string email1, Image photo1, int group1, Subjects subj1) 
            : base(name1, surname1, age1, adress1, email1, photo1)
        {
            group1 = group;
            subj1 = subj;
            listofCoursework = new List<Coursework>();
        }
        public Student(Student student) 
            : base(student.name, student.surname, student.age, student.adress, student.email, student.photo)
        {
            this.group = student.group;
            this.subj = student.subj;
            this.listofCoursework = student.listofCoursework;
        }

        public void AddCoursework(Coursework coursework)
        {
            listofCoursework.Add(coursework);
        }
        
        public Student(string name1,string surname1, Image photo1,Subjects subj1) 
            : base(name1,surname1,photo1)
        {
        	subj1 = subj;
            listofCoursework = new List<Coursework>();
        }
        
        public void RemoveCoursework(Coursework coursework)
        {
            if (listofCoursework.Contains(coursework))
            {
                listofCoursework.Remove(coursework);
            }
        }
        public void ClearCoursework()
        {
            listofCoursework.Clear();
        }
        public List<Coursework> ListCoursework
        {
            get { return listofCoursework; }
        }

        public int Group
        {
            get { return group; }
            set { group = value; }
        }
        public Subjects Ssubj
        {
            get { return subj; }
            set { subj = value; }
        }
       
    }
}
