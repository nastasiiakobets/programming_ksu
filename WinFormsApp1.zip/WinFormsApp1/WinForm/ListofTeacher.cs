﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class ListofTeacher
    {
        private List<Teacher> listTeacher;
        public ListofTeacher()
        {
            listTeacher = new List<Teacher>();
        }
        public ListofTeacher(ListofTeacher listTeacher)
        {
            this.listTeacher = listTeacher.LTeacher;
        }

        public void add(Teacher teacher)
        {
            listTeacher.Add(teacher);
        }
        public void removeTeacher(Teacher teacher)
        {
            if (listTeacher.Contains(teacher))
            {
                listTeacher.Remove(teacher);
            }
        }
        public void _Clear()
        {
            listTeacher.Clear();
        }

        public List<Teacher> LTeacher
        {
            get { return listTeacher; }
            set { this.listTeacher = value; }
        }
    }
}
