﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinForm
{
	
	public partial class AddFormStudent : Form
	{
		private MainForm _mainform;
		private UserControls.UserControl1 _userControl1;
		
		
		public AddFormStudent(MainForm mainform, UserControls.UserControl1 usercontrol1)
		{
			this._mainform = mainform;
			this._userControl1 = usercontrol1;
			InitializeComponent();
			
		}
		void button_add_student_Click(object sender, EventArgs e)
		{
			label1.Text = " ";
			string stud_name = textBox_Name.Text;
			string stud_surname = textBox_Surname.Text;
			Image photos = pictureBox1.Image;
			Key key;
			if (Key.TryParse(textBox_key.Text, out key)) 
			{
				
				_userControl1.Teach.addStudent(new Student(stud_name,stud_surname,photos,key));
				string value = _userControl1.Teach.addStudent(new Student(stud_name,stud_surname,photos,key));
				if(!(string.IsNullOrWhiteSpace(value)))
				{
					label1.Text = value;
				}
				_mainform.PrintTeacher();
			
			}
			else
			{
				label1.Text = "Поле Key введено не корректно";
			}
		}
		void pictureBox1_Click(object sender, EventArgs e)
		{
			openFileDialog1.ShowDialog();
			string FilePath = openFileDialog1.FileName;
			pictureBox1.Image = Image.FromFile(FilePath);
		}
	}
}
