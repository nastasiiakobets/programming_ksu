﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using WinFormsApp1;

namespace WinFormsApp1
{

    public partial class Graphs : Form
    {
        private MainForm _mainform;
        private ListofTeacher _listteacher;

        public Graphs(MainForm mainform, ListofTeacher listteacher)
        {
            this._mainform = mainform;
            this._listteacher = listteacher;
            InitializeComponent();

           
            new_chart();
        }

       

        private void new_chart()
        {
            chart3.Series[0].Points.Clear();
            chart4.Series[0].Points.Clear();

            for (int i = 0; i < _mainform.teacher_list.LTeacher.Count; i++)
            {
                Teacher itemChart2 = _mainform.teacher_list.LTeacher[i];
                chart4.Series["Students"].Points.AddXY(
                    itemChart2.Name + itemChart2.Surname, itemChart2.ListStudent.Count);
                for (int j = 0; j < _mainform.teacher_list.LTeacher[i].ListStudent.Count; j++)
                {
                    Student itemChart = _mainform.teacher_list.LTeacher[i].ListStudent[j];
                    chart3.Series["Coursework"].Points.AddXY(itemChart.Name + itemChart.Surname,
                        itemChart.ListCoursework.Count);
                }
            }
        }

    

        private void chart3_Click(object sender, EventArgs e)
        {

        }

        private void chart4_Click(object sender, EventArgs e)
        {

        }

        private void Graphs_Load(object sender, EventArgs e)
        {

        }
    }
}
