﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;

namespace WinFormsApp1
{
	
	public partial class Graphandtreetview : Form
	{
		private MainForm _mainform;
		private ListofTeacher _listteacher;
		
		public Graphandtreetview(MainForm mainform,ListofTeacher listteacher)
		{
			this._mainform = mainform;
			this._listteacher = listteacher;
			InitializeComponent();
			
			new_TreeView();
			new_chart();
		}
		
		private void new_TreeView()
		{
			DateTime deadline;
			Color color = Color.Black;
			treeView1.Nodes.Clear();
			for(int i = 0;i < _mainform.teacher_list.LTeacher.Count;i++)
			{
				treeView1.Nodes.Add(_mainform.teacher_list.LTeacher[i].Name + _mainform.teacher_list.LTeacher[i].Surname);
				for(int k = 0;k < _mainform.teacher_list.LTeacher[i].ListStudent.Count;k++)
				{
					treeView1.Nodes[i].Nodes.Add(_mainform.teacher_list.LTeacher[i].ListStudent[k].Name + _mainform.teacher_list.LTeacher[i].ListStudent[k].Surname);
					for(int j = 0; j < _mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework.Count;j++)
					{
						treeView1.Nodes[i].Nodes[k].Nodes.Add(_mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Title);
						deadline = _mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Date;
						if(deadline<DateTime.Today)
						{
							color = Color.Red;
						}
						else
						{
							color = Color.Black;
						}
						treeView1.Nodes[i].Nodes[k].Nodes[j].Nodes.Add((_mainform.teacher_list.LTeacher[i].ListStudent[k].ListCoursework[j].Date).ToShortDateString()).ForeColor = color;
					}
					 
				}
			}
		}
		
		private void new_chart()
		{
			chart1.Series[0].Points.Clear();
            chart2.Series[0].Points.Clear();

            for (int i = 0; i < _mainform.teacher_list.LTeacher.Count; i++)
            {
            	Teacher itemChart2 = _mainform.teacher_list.LTeacher[i];
            	chart2.Series["Students"].Points.AddXY(itemChart2.Name + itemChart2.Surname, itemChart2.ListStudent.Count);
                for (int j = 0; j < _mainform.teacher_list.LTeacher[i].ListStudent.Count; j++)
                {
                    Student itemChart = _mainform.teacher_list.LTeacher[i].ListStudent[j];
                    chart1.Series["Coursework"].Points.AddXY(itemChart.Name + itemChart.Surname, itemChart.ListCoursework.Count);
                }
            }
		}

        private void AddDetails_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
