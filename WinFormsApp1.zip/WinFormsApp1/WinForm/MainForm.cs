﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using UserControl1;

namespace WinFormsApp1
{
	
	public partial class MainForm : Form
	{
		
		private Form _Active;
		public ListofTeacher teacher_list = new ListofTeacher();
		
		public MainForm()
		{
			InitializeComponent();
			
		}
		
		public void TeacherImage()
		{
			
		}
		
		public void PrintTeacher()
		{
			
			flowLayoutPanel1.Controls.Clear();
			for(int i = 0; i<teacher_list.LTeacher.Count; i++)
			{
				Teacher itemTeach = teacher_list.LTeacher[i];
				flowLayoutPanel1.Controls.Add(new UserControls.Controler1(itemTeach,this));
				for(int j = 0; j<teacher_list.LTeacher[i].ListStudent.Count; j++)
				{
					Student itemStudent = itemTeach.ListStudent[j];
					flowLayoutPanel1.Controls.Add(new UserControls.Controler2(itemStudent,this,itemTeach));
					for(int k = 0; k<teacher_list.LTeacher[i].ListStudent[j].ListCoursework.Count;k++)
					{
						Coursework itemCourse = itemStudent.ListCoursework[k];
						flowLayoutPanel1.Controls.Add(new UserControls.Controler3(itemCourse,this,itemStudent));
					}
				}
			}
		}
		
		void Button3Click(object sender, EventArgs e)
		{
			Graphs newDetails = new Graphs(this, teacher_list);
			newDetails.Show();
		}
		
		void add_default_teacher_Click(object sender, EventArgs e)
		{
			Image img = Image.FromFile(Application.StartupPath + @"\image\user.png");
			teacher_list.add(new Teacher("Name","Surname",img,Subjects.Math));
			PrintTeacher();
		}
       

        void button1_Click(object sender, EventArgs e)
		{
			OpenItem(new AddTeacher(this));
		}
		
		public void OpenItem(Form item)
        {
            if (_Active != null)
            { _Active.Close(); }

            _Active = item;
            item.TopLevel = false;
            item.FormBorderStyle = FormBorderStyle.None;

            this.panel1.Controls.Add(item);
            item.BringToFront();
            item.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

		private void button2_Click(object sender, EventArgs e)
		{

			Treetview newDetails = new Treetview(this, teacher_list);
			newDetails.Show();

		}
	}
}
