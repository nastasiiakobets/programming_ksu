﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Text;
//using System.Text.Json;
//using System.Text.Json.Serialization;

namespace WinFormsApp1
{
    public enum Subjects { Math, Physics, Biology, Programming, History, English };
    public class Human
    {
        protected string name;
        protected string surname;
        protected int age;
        protected Image photo;
        protected Adress adress;
        protected string email;
        

        public Human()
        {
            name = "Anastasiia";
            surname = "Kobets";
            age = 18;
            photo = Image.FromFile(Application.StartupPath + @"\image\default.jpg");
            adress = new Adress();
            email = "anastasiiakobets@email.com";
        }
        
        public Human(string name1,string surname1,Image photo1)
        {
        	name = name1;
        	surname = surname1;
        	age = 18;
            adress = new Adress();
            photo = photo1;
            email = "namesurname@email.com";
        }
        
        public Human(string name1, string surname1, int age1, Adress adress1, string email1, Image photo1)
        {
           name = name1;
            surname = surname1;
            age = age1;
            adress = adress1; 
            photo = photo1;
            email = email1;
        }
        public Human(Human hum)
        {
            this.name = hum.name;
            this.surname = hum.surname;
            this.age = hum.age;
            this.adress = hum.adress; 
            this.photo = hum.photo;
            this.email = hum.email;
        }
        public void WriteToJson(string pathToFile)
        {
            //File.WriteAllText(pathToFile, JsonConvert.SerializeObject(this));
            
        }
        public void ChangeInf()
        {
            Console.WriteLine("Введіть нові дані: ");
            Console.WriteLine("Ім'я: ");
            Name = Console.ReadLine();
            Console.WriteLine("Прізвище: ");
            Surname = Console.ReadLine();
            Console.WriteLine("Вік: "); 
            Age = Int32.Parse(Console.ReadLine());
        }
        public static bool operator >(Human one, Human two)
        {
            return one.age > two.age;
        }
        public static bool operator <(Human one, Human two)
        {
            return one.age < two.age;
        }
       
        public string dataToStr()
        {
            string str;
            str = "Ім'я: " + this.name + "\n"
                +"Прізвище: " + this.surname + "\n"
                +"Вік: " + this.age.ToString() + "\n" 
                + "Email: " + this.email
                +"Адреса: " + adress.adressToString();
            return str;
        }
        public virtual void printInfo()
        {
            Console.WriteLine(dataToStr());
        }



        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public Adress Adress
        {
            get { return adress; }
            set { adress = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public Image Photo
        {
            get { return photo; }
            set { photo = value; }
        }
    }
}